import json
import os
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from datetime import datetime

LOG_DIR = "./logs/changes.json"  # Log dosyası yolu
WATCH_DIR = "./test"             # İzlenecek dizin

class ChangeHandler(FileSystemEventHandler):
    def on_any_event(self, event):
        change = {
            "event_type": event.event_type,
            "path": event.src_path,
            "is_directory": event.is_directory,
            "timestamp": datetime.now().isoformat()
        }
        self.log_change(change)

    def log_change(self, change):
        os.makedirs(os.path.dirname(LOG_DIR), exist_ok=True)
        if not os.path.exists(LOG_DIR):
            with open(LOG_DIR, "w") as f:
                json.dump([], f)
        
        with open(LOG_DIR, "r+") as f:
            data = json.load(f)
            data.append(change)
            f.seek(0)
            json.dump(data, f, indent=4)

if __name__ == "__main__":
    os.makedirs(WATCH_DIR, exist_ok=True)
    event_handler = ChangeHandler()
    observer = Observer()
    observer.schedule(event_handler, WATCH_DIR, recursive=True)
    observer.start()
    print(f"Watching for changes in: {WATCH_DIR}")
    try:
        while True:
            pass
    except KeyboardInterrupt:
        observer.stop()
    observer.join()