# Python Watchdog Project

Bu proje, bir dizindeki değişiklikleri izleyen ve bu değişiklikleri JSON formatında bir log dosyasına kaydeden bir Python uygulamasıdır.

## Özellikler
- Dosya/dizin oluşturma, değiştirme ve silme olaylarını izler.
- Değişiklikleri JSON formatında bir log dosyasına kaydeder.
- Systemd servisi olarak yapılandırılabilir.

## Kullanım

1. **Bağımlılıkları yükleyin:**
   ```bash
   pip install -r requirements.txt
   ```

2. **Python scriptini çalıştırın:**
   ```bash
   python watchdog_script.py
   ```

3. **Servis olarak yapılandırmak için:**
   - `systemd/watchdog.service` dosyasını `/etc/systemd/system` dizinine kopyalayın.
   - Servisi başlatın:
     ```bash
     sudo systemctl daemon-reload
     sudo systemctl start watchdog.service
     ```

4. **Test için:**
   - `test/` dizininde dosya oluşturun veya silin.
   - Değişikliklerin `logs/changes.json` dosyasına kaydedildiğini görün.

## Dizin Yapısı
```
project-name/
├── README.md
├── requirements.txt
├── watchdog_script.py
├── logs/
├── test/
└── systemd/
    └── watchdog.service
```